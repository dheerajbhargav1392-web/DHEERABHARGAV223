const menu=document.querySelector(".menu");
const nav=document.querySelector("#nav-links");
menu?.addEventListener("click",()=>{nav.style.display=nav.style.display==="flex"?"none":"flex";});
document.querySelectorAll("#nav-links a").forEach(a=>a.addEventListener("click",()=>{if(innerWidth<=800)nav.style.display="none"}));
