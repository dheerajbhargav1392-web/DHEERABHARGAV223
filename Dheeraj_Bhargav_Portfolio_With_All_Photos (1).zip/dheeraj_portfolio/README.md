# Dheeraj Bhargav Portfolio

Responsive professional portfolio website with resume and portrait gallery.

## Included
- `index.html`
- `style.css`
- `script.js`
- `assets/Dheeraj_Bhargav_Resume.pdf`
- `assets/profile.jpg`
- `assets/profile-01.jpg` through `profile-04.jpg`

The portrait gallery is for professional presentation and should not be used to imply employment at any company shown in the original source photos.

## GitHub Pages
Create a repository named `YOUR-USERNAME.github.io`, upload these files, then enable GitHub Pages from Settings → Pages using the main branch.
